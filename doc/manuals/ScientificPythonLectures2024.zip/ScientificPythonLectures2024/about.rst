.. only:: latex

   ====================================
   About the Scientific Python Lectures
   ====================================


   About the Scientific Python Lectures
   ====================================

   Release: |release|

   The lectures are archived on zenodo: http://dx.doi.org/10.5281/zenodo.594102

   All code and material is licensed under a
   Creative Commons Attribution 4.0 International License (CC-by)
   http://creativecommons.org/licenses/by/4.0/

   .. raw:: latex

      \begin{multicols}{2}

   .. toctree::

      AUTHORS.rst

   .. raw:: latex

      \end{multicols}
