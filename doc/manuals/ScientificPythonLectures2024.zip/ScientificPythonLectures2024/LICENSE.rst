License
========

All code and material is licensed under a

Creative Commons Attribution 4.0 International License (CC-by)

https://creativecommons.org/licenses/by/4.0/

See the AUTHORS.rst file for a list of contributors.
