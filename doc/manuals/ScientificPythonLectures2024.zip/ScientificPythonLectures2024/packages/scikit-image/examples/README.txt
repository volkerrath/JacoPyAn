Examples for the scikit-image chapter
======================================
