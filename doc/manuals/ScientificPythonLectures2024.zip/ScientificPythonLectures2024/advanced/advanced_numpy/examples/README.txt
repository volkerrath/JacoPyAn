Examples for the advanced NumPy chapter
=======================================
