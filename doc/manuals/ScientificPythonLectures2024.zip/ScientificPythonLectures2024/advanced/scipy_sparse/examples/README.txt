Examples for the SciPy sparse array chapter
============================================
