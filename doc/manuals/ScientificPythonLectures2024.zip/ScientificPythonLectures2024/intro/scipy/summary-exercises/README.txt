Examples for the summary exercises
==================================
