Full code examples for the SciPy chapter
----------------------------------------
